export { default as AddFactory } from './AddFactory';
export { default as ClickInput } from './ClickInput';
export { default as Factory } from './Factory';